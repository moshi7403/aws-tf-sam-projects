import json
import boto3
import os

s3 = boto3.client('s3')
FINAL_BUCKET = os.environ['FINAL_BUCKET']

def handler(event, context):
    for record in event['Records']:
        src_bucket = record['s3']['bucket']['name']
        src_key = record['s3']['object']['key']

        copy_source = {
            'Bucket': src_bucket,
            'Key': src_key
        }

        new_key = f"processed/{src_key.split('/')[-1]}"

        s3.copy_object(
            CopySource=copy_source,
            Bucket=FINAL_BUCKET,
            Key=new_key
        )

        s3.delete_object(Bucket=src_bucket, Key=src_key)

    return {
        'statusCode': 200,
        'body': json.dumps('File moved successfully!')
    }